/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Koneksi;

import java.sql.DriverManager;
import java.sql.SQLException;
import javax.swing.JOptionPane;

public class koneksi {
    
    private static java.sql.Connection koneksi;

    public static java.sql.Connection getKoneksi() {
        if (koneksi == null) {
            try {
                // Sesuaikan URL, user, dan password dengan database kamu
                String url = "jdbc:mysql://localhost:3306/db_julian?serverTimezone=UTC";
                String user = "root"; // ganti jika user berbeda
                String pass = "";     // ganti jika pakai password

                // Load driver
                Class.forName("com.mysql.cj.jdbc.Driver");

                // Buat koneksi
                koneksi = DriverManager.getConnection(url, user, pass);
                System.out.println("Koneksi berhasil!");
            } catch (ClassNotFoundException | SQLException e) {
                System.err.println("Koneksi gagal: " + e.getMessage());
                e.printStackTrace();
            }
        }
        return koneksi;
    }
}
